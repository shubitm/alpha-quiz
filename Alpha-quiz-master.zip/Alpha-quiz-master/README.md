# Alpha-quiz-system 🎯
Alpha quiz system is a quiz-based game. similar to different online-based exam virtual environments with proper timer and submit button. The report card will be generated automatically after the given time expires or after answering all the questions.
# Screenshot 📕📜
![{E7101070-64D1-4448-ABE5-A1978224357E} png](https://user-images.githubusercontent.com/70909882/118395100-42e2a080-b666-11eb-9b2a-6e3dc2a78db7.jpg)


![{0BE525AF-214C-437E-83F8-A7ABF67D7AA9} png](https://user-images.githubusercontent.com/70909882/118395107-45dd9100-b666-11eb-8d3d-db2dc0bc24eb.jpg)


![{6C873019-1BA6-4D30-B6AE-E63FAA6F11D5} png](https://user-images.githubusercontent.com/70909882/118395377-b507b500-b667-11eb-8677-33ac3b058356.jpg)
